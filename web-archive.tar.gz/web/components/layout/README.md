package layout

// This file provides easy imports for all organism components
// Organisms are complex components made from atoms and molecules

// Available Organisms:
// - Accordion: @accordion.templ - Collapsible content sections
// - BottomNavigation: @bottom_navigation.templ - Mobile navigation
// - Carousel: @carousel.templ - Image and content sliders  
// - DataTable: @datatable.templ - Advanced data tables with sorting/filtering
// - Dropdown: @dropdown.templ - Complex dropdown menus
// - Modal: @modal.templ - Modal dialogs and overlays
// - Navbar: @navbar.templ - Main navigation headers
// - Sidebar: @sidebar.templ - Side navigation panels
// - Tabs: @tabs.templ - Tabbed content interfaces

// Usage example:
// @organisms.DataTable(types.DataTableProps{Columns: columns, Data: data})