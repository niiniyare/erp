package infrastructure

import (
	"context"
	"fmt"

	"github.com/niiniyare/erp/internal/platform/config"
	"github.com/niiniyare/erp/internal/shared/logger"
)

// Container manages all infrastructure components
type Container struct {
	config        *config.Config
	database      *Database
	observability *Observability
	temporal      *Temporal
}

// NewContainer creates a new infrastructure container
func NewContainer(cfg *config.Config) *Container {
	return &Container{
		config: cfg,
	}
}

// Start initializes all infrastructure components
func (c *Container) Start(ctx context.Context) error {
	// Initialize observability first (logging, metrics, tracing)
	obs, err := InitializeObservability(c.config)
	if err != nil {
		return fmt.Errorf("failed to initialize observability: %w", err)
	}
	c.observability = obs

	// Initialize database
	db, err := InitializeDatabase(c.config)
	if err != nil {
		return fmt.Errorf("failed to initialize database: %w", err)
	}
	c.database = db

	// Initialize temporal
	temp, err := InitializeTemporal(c.config, c.observability.Logger)
	if err != nil {
		return fmt.Errorf("failed to initialize temporal: %w", err)
	}
	c.temporal = temp

	logger.Info("Infrastructure container started successfully")
	return nil
}

// Stop gracefully shuts down all infrastructure components
func (c *Container) Stop(ctx context.Context) error {
	logger.Info("Stopping infrastructure container")

	// Stop temporal
	if c.temporal != nil {
		if err := c.temporal.Shutdown(ctx); err != nil {
			logger.Error("Failed to shutdown temporal", logger.Fields{"error": err.Error()})
		}
	}

	// Stop observability
	if c.observability != nil {
		if err := c.observability.Shutdown(ctx); err != nil {
			logger.Error("Failed to shutdown observability", logger.Fields{"error": err.Error()})
		}
	}

	// Close database connections
	if c.database != nil {
		if err := c.database.Close(); err != nil {
			logger.Error("Failed to close database", logger.Fields{"error": err.Error()})
		}
	}

	logger.Info("Infrastructure container stopped")
	return nil
}

// Health checks all infrastructure components
func (c *Container) Health(ctx context.Context) error {
	if c.database == nil || c.observability == nil || c.temporal == nil {
		return fmt.Errorf("infrastructure components not initialized")
	}

	// Basic health checks could be added here
	// For now, just ensure components are not nil
	return nil
}

// GetDatabase returns the database component
func (c *Container) GetDatabase() *Database {
	return c.database
}

// GetObservability returns the observability component
func (c *Container) GetObservability() *Observability {
	return c.observability
}

// GetMessaging returns the temporal component (acting as messaging)
func (c *Container) GetMessaging() *Temporal {
	return c.temporal
}

// GetCache returns the cache service from database component
func (c *Container) GetCache() *Database {
	return c.database
}
