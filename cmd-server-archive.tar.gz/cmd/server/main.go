//go:build !test

package main

import (
	"context"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/niiniyare/erp/cmd/server/bootstrap"
	"github.com/niiniyare/erp/internal/core"
	"github.com/niiniyare/erp/internal/shared/logger"

	_ "github.com/golang-migrate/migrate/v4/database/postgres"
	_ "github.com/golang-migrate/migrate/v4/source/file"
)

func main() {
	// Handle potential panics from config loading
	defer func() {
		if r := recover(); r != nil {
			logger.Fatal("Configuration loading failed", logger.Fields{
				"error": r,
				"hint":  "Please ensure environment variables are set: DB_HOST, DB_NAME, DB_USER, DB_PASSWORD",
			})
		}
	}()

	// Initialize application infrastructure
	app, err := bootstrap.NewApplication()
	if err != nil {
		logger.Fatal("Failed to initialize application", logger.Fields{"error": err.Error()})
	}

	// Create context for graceful shutdown
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Start application infrastructure
	if err := app.Start(ctx); err != nil {
		logger.Fatal("Failed to start application infrastructure", logger.Fields{"error": err.Error()})
	}

	// Get infrastructure dependencies (after infrastructure is started)
	deps, err := app.GetCoreDependencies()
	if err != nil {
		logger.Fatal("Failed to get core dependencies", logger.Fields{"error": err.Error()})
	}

	// Initialize core service container
	serviceContainer, err := core.NewServiceContainer(deps)
	if err != nil {
		logger.Fatal("Failed to create service container", logger.Fields{"error": err.Error()})
	}

	// Initialize all core services
	if err := serviceContainer.Initialize(ctx); err != nil {
		logger.Fatal("Failed to initialize core services", logger.Fields{"error": err.Error()})
	}

	// Initialize HTTP server
	httpServer, err := bootstrap.NewHTTPServer(app, serviceContainer)
	if err != nil {
		logger.Fatal("Failed to initialize HTTP server", logger.Fields{"error": err.Error()})
	}

	// Start HTTP server in a goroutine
	go func() {
		logger.Info("Starting HTTP server", logger.Fields{
			"port":    app.Config.Server.Port,
			"address": ":" + app.Config.Server.Port,
			"app":     app.Config.App.Name,
			"version": app.Config.App.Version,
		})

		if err := httpServer.Start(":" + app.Config.Server.Port); err != nil {
			logger.Fatal("HTTP server failed to start", logger.Fields{
				"error": err.Error(),
				"port":  app.Config.Server.Port,
			})
		}
	}()

	// Setup graceful shutdown
	gracefulShutdown(ctx, cancel, httpServer, serviceContainer, app)
}

// gracefulShutdown handles graceful shutdown of the application
func gracefulShutdown(
	ctx context.Context,
	cancel context.CancelFunc,
	httpServer *bootstrap.HTTPServer,
	serviceContainer *core.ServiceContainer,
	app *bootstrap.Application,
) {
	// Create a channel to receive OS signals
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)

	// Block until we receive a signal
	<-quit
	logger.Info("Received shutdown signal, starting graceful shutdown...")

	// Cancel the main context
	cancel()

	// Create shutdown context with timeout
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer shutdownCancel()

	// Shutdown HTTP server
	if err := httpServer.Shutdown(shutdownCtx); err != nil {
		logger.Error("Failed to shutdown HTTP server gracefully", logger.Fields{
			"error": err.Error(),
		})
	} else {
		logger.Info("HTTP server stopped")
	}

	// Shutdown core services
	if err := serviceContainer.Shutdown(shutdownCtx); err != nil {
		logger.Error("Failed to shutdown core services", logger.Fields{
			"error": err.Error(),
		})
	} else {
		logger.Info("Core services stopped")
	}

	// Shutdown application infrastructure
	if err := app.Stop(shutdownCtx); err != nil {
		logger.Error("Failed to shutdown application infrastructure", logger.Fields{
			"error": err.Error(),
		})
	} else {
		logger.Info("Application infrastructure stopped")
	}

	logger.Info("Graceful shutdown completed")
}
