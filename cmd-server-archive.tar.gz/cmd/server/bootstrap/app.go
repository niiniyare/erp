package bootstrap

import (
	"context"
	"fmt"

	"github.com/niiniyare/erp/cmd/server/infrastructure"
	"github.com/niiniyare/erp/internal/core"
	"github.com/niiniyare/erp/internal/platform/config"
	"github.com/niiniyare/erp/internal/shared/logger"
)

// Application manages the overall application lifecycle and infrastructure
type Application struct {
	Config         *config.Config
	Infrastructure *infrastructure.Container
}

// NewApplication creates a new application instance
func NewApplication() (*Application, error) {
	// Load configuration
	cfg, _ := config.LoadWithViper()

	if err := cfg.Validate(); err != nil {
		return nil, fmt.Errorf("invalid configuration: %w", err)
	}

	// Log successful configuration load
	logger.Info("Configuration loaded successfully", logger.Fields{
		"app_name": cfg.App.Name,
		"version":  cfg.App.Version,
		"stage":    cfg.App.Stage,
		"port":     cfg.Server.Port,
	})

	// Create infrastructure container
	infrastructure := infrastructure.NewContainer(cfg)

	return &Application{
		Config:         cfg,
		Infrastructure: infrastructure,
	}, nil
}

// Start initializes and starts the application infrastructure
func (a *Application) Start(ctx context.Context) error {
	logger.Info("Starting application infrastructure", logger.Fields{
		"app":     a.Config.App.Name,
		"version": a.Config.App.Version,
		"stage":   a.Config.App.Stage,
	})

	// Start infrastructure components
	if err := a.Infrastructure.Start(ctx); err != nil {
		return fmt.Errorf("failed to start infrastructure: %w", err)
	}

	logger.Info("Application infrastructure started successfully")
	return nil
}

// Stop gracefully shuts down the application infrastructure
func (a *Application) Stop(ctx context.Context) error {
	logger.Info("Stopping application infrastructure")

	if err := a.Infrastructure.Stop(ctx); err != nil {
		return fmt.Errorf("failed to stop infrastructure: %w", err)
	}

	logger.Info("Application infrastructure stopped successfully")
	return nil
}

// Health checks the health of the application infrastructure
func (a *Application) Health(ctx context.Context) error {
	return a.Infrastructure.Health(ctx)
}

// GetCoreDependencies extracts the dependencies needed by the core service container
func (a *Application) GetCoreDependencies() (core.Dependencies, error) {
	if a == nil {
		return core.Dependencies{}, fmt.Errorf("application is nil")
	}

	if a.Infrastructure == nil {
		return core.Dependencies{}, fmt.Errorf("infrastructure not initialized")
	}

	// Get infrastructure components
	database := a.Infrastructure.GetDatabase()
	observability := a.Infrastructure.GetObservability()
	temporal := a.Infrastructure.GetMessaging()
	cache := a.Infrastructure.GetCache()

	// Validate required components
	if database == nil {
		return core.Dependencies{}, fmt.Errorf("database component not available")
	}
	if observability == nil {
		return core.Dependencies{}, fmt.Errorf("observability component not available")
	}

	// Create core dependencies
	deps := core.Dependencies{
		Store:    database.GetStore(),
		Cache:    cache.GetClient(),
		Logger:   observability.GetLogger(),
		Metrics:  observability.GetMetrics(),
		Tracing:  observability.GetTracing(),
		Temporal: temporal.GetPlatform(),
	}

	// Validate dependencies
	if err := deps.Validate(); err != nil {
		return core.Dependencies{}, fmt.Errorf("invalid core dependencies: %w", err)
	}

	return deps, nil
}
