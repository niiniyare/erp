package bootstrap

import (
	"context"
	"fmt"
	"net/http"
	"time"

	"github.com/niiniyare/erp/internal/core"
	"github.com/niiniyare/erp/internal/shared/logger"
)

// HTTPServer manages the HTTP server lifecycle
type HTTPServer struct {
	server *http.Server
	config *Application
	logger logger.Logger
}

// NewHTTPServer creates a new HTTP server with the given configuration and services
func NewHTTPServer(app *Application, serviceContainer *core.ServiceContainer) (*HTTPServer, error) {
	if app == nil {
		return nil, fmt.Errorf("application is required")
	}
	if serviceContainer == nil {
		return nil, fmt.Errorf("service container is required")
	}

	// Get logger from service container
	deps, err := app.GetCoreDependencies()
	if err != nil {
		return nil, fmt.Errorf("failed to get dependencies: %w", err)
	}

	// Create HTTP handler/router with service container
	handler := createHTTPHandler(serviceContainer)

	// Create HTTP server
	server := &http.Server{
		Handler:           handler,
		ReadHeaderTimeout: 60 * time.Second,
		ReadTimeout:       app.Config.Server.ReadTimeout,
		WriteTimeout:      app.Config.Server.WriteTimeout,
		IdleTimeout:       120 * time.Second,
	}

	return &HTTPServer{
		server: server,
		config: app,
		logger: deps.Logger.WithFields(logger.Fields{"component": "http_server"}),
	}, nil
}

// Start starts the HTTP server on the given address
func (s *HTTPServer) Start(addr string) error {
	s.server.Addr = addr

	s.logger.Info("HTTP server starting", logger.Fields{
		"address": addr,
		"config": map[string]interface{}{
			"read_timeout":        s.server.ReadTimeout,
			"write_timeout":       s.server.WriteTimeout,
			"read_header_timeout": s.server.ReadHeaderTimeout,
			"idle_timeout":        s.server.IdleTimeout,
		},
	})

	if err := s.server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		return fmt.Errorf("HTTP server failed: %w", err)
	}

	return nil
}

// Shutdown gracefully shuts down the HTTP server
func (s *HTTPServer) Shutdown(ctx context.Context) error {
	s.logger.Info("Shutting down HTTP server")

	if err := s.server.Shutdown(ctx); err != nil {
		return fmt.Errorf("failed to shutdown HTTP server: %w", err)
	}

	s.logger.Info("HTTP server shut down successfully")
	return nil
}

// createHTTPHandler creates the main HTTP handler/router with web UI integration
func createHTTPHandler(serviceContainer *core.ServiceContainer) http.Handler {
	mux := http.NewServeMux()

	// Use a simple logger approach for web handler
	log := &simpleLogger{}

	// Initialize web handler for UI routes and APIs
	webHandler := NewWebHandler(serviceContainer, log)
	webHandler.RegisterRoutes(mux)

	// Health check endpoint
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		ctx := r.Context()

		// Check service container health
		if err := serviceContainer.Health(ctx); err != nil {
			http.Error(w, fmt.Sprintf("Service unhealthy: %v", err), http.StatusServiceUnavailable)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"status":"healthy","services":"operational"}`))
	})

	// Version endpoint
	mux.HandleFunc("/version", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"version":"1.0.0","service":"erp-core"}`))
	})

	// Root endpoint - redirect to dashboard
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/" {
			http.Redirect(w, r, "/dashboard", http.StatusTemporaryRedirect)
			return
		}
		http.NotFound(w, r)
	})

	return mux
}

// simpleLogger implements a basic logger interface for web handler
type simpleLogger struct{}

func (s *simpleLogger) Debug(msg string, fields ...logger.Fields) {
	logger.Debug(msg, fields...)
}

func (s *simpleLogger) Info(msg string, fields ...logger.Fields) {
	logger.Info(msg, fields...)
}

func (s *simpleLogger) Warn(msg string, fields ...logger.Fields) {
	logger.Warn(msg, fields...)
}

func (s *simpleLogger) Error(msg string, fields ...logger.Fields) {
	logger.Error(msg, fields...)
}

func (s *simpleLogger) Fatal(msg string, fields ...logger.Fields) {
	logger.Fatal(msg, fields...)
}

func (s *simpleLogger) DebugContext(ctx context.Context, msg string, fields ...logger.Fields) {
	logger.DebugContext(ctx, msg, fields...)
}

func (s *simpleLogger) InfoContext(ctx context.Context, msg string, fields ...logger.Fields) {
	logger.InfoContext(ctx, msg, fields...)
}

func (s *simpleLogger) WarnContext(ctx context.Context, msg string, fields ...logger.Fields) {
	logger.WarnContext(ctx, msg, fields...)
}

func (s *simpleLogger) ErrorContext(ctx context.Context, msg string, fields ...logger.Fields) {
	logger.ErrorContext(ctx, msg, fields...)
}

func (s *simpleLogger) WithFields(fields logger.Fields) logger.Logger {
	return s
}

func (s *simpleLogger) WithContext(ctx context.Context) logger.Logger {
	return s
}

func (s *simpleLogger) SetLevel(level logger.LogLevel) {
	// No-op for simple logger
}

func (s *simpleLogger) Close() error {
	return nil
}
