package bootstrap

import (
	"context"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/a-h/templ"
	"github.com/niiniyare/erp/internal/core"
	"github.com/niiniyare/erp/internal/shared/logger"
	genTenant "github.com/niiniyare/erp/internal/api/gen/tenant"
	tenantComponents "github.com/niiniyare/erp/web/components/tenant"
)

// WebHandler manages web UI routes and static assets
type WebHandler struct {
	serviceContainer *core.ServiceContainer
	logger           logger.Logger
}

// NewWebHandler creates a new web handler
func NewWebHandler(serviceContainer *core.ServiceContainer, log logger.Logger) *WebHandler {
	return &WebHandler{
		serviceContainer: serviceContainer,
		logger:           log.WithFields(logger.Fields{"component": "web_handler"}),
	}
}

// RegisterRoutes registers web UI routes to the given mux
func (w *WebHandler) RegisterRoutes(mux *http.ServeMux) {
	// Serve static assets
	w.registerStaticRoutes(mux)
	
	// Register UI pages
	w.registerUIRoutes(mux)
	
	// Register tenant UI routes with content negotiation
	w.registerTenantUIRoutes(mux)
	
	// Register API routes that support content negotiation
	w.registerAPIRoutes(mux)
	
	w.logger.Info("Web UI routes registered successfully")
}

// registerStaticRoutes sets up static file serving
func (w *WebHandler) registerStaticRoutes(mux *http.ServeMux) {
	// Serve JavaScript assets
	mux.HandleFunc("/assets/", w.serveStaticAssets)
	
	w.logger.Info("Static asset routes registered", logger.Fields{
		"prefix": "/assets/",
	})
}

// serveStaticAssets serves static files from the web/assets directory
func (wh *WebHandler) serveStaticAssets(w http.ResponseWriter, r *http.Request) {
	// Remove leading slash and convert path
	requestPath := strings.TrimPrefix(r.URL.Path, "/")
	
	// Build file path relative to project root
	filePath := filepath.Join("web", requestPath)
	
	// Check if file exists
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		http.NotFound(w, r)
		return
	}
	
	// Set appropriate content type based on file extension
	ext := filepath.Ext(requestPath)
	switch ext {
	case ".js":
		w.Header().Set("Content-Type", "application/javascript")
	case ".css":
		w.Header().Set("Content-Type", "text/css")
	case ".json":
		w.Header().Set("Content-Type", "application/json")
	}
	
	// Set cache headers for assets
	w.Header().Set("Cache-Control", "public, max-age=31536000")
	
	// Serve the file
	http.ServeFile(w, r, filePath)
}

// registerUIRoutes sets up UI page routes
func (w *WebHandler) registerUIRoutes(mux *http.ServeMux) {
	// Dashboard route
	mux.HandleFunc("/dashboard", w.serveDashboard)
	
	// Components demo route  
	mux.HandleFunc("/components", w.serveComponentsDemo)
	
	// Default UI route (redirect to dashboard)
	mux.HandleFunc("/ui", func(wr http.ResponseWriter, r *http.Request) {
		http.Redirect(wr, r, "/dashboard", http.StatusTemporaryRedirect)
	})
	
	w.logger.Info("UI page routes registered", logger.Fields{
		"routes": []string{"/dashboard", "/components", "/ui"},
	})
}

// registerTenantUIRoutes sets up tenant management UI routes
func (w *WebHandler) registerTenantUIRoutes(mux *http.ServeMux) {
	// Tenant list page
	mux.HandleFunc("/tenants", w.serveTenantListPage)
	
	// New tenant form page  
	mux.HandleFunc("/tenants/new", w.serveTenantNewPage)
	
	// Edit tenant form page
	mux.HandleFunc("/tenants/edit/", w.serveTenantEditPage)
	
	// View tenant detail page
	mux.HandleFunc("/tenants/view/", w.serveTenantViewPage)
	
	w.logger.Info("Tenant UI routes registered", logger.Fields{
		"routes": []string{"/tenants", "/tenants/new", "/tenants/edit/*", "/tenants/view/*"},
	})
}

// registerAPIRoutes sets up API routes with content negotiation support
func (w *WebHandler) registerAPIRoutes(mux *http.ServeMux) {
	// Tenant API routes that support both JSON and HTML responses
	mux.HandleFunc("/api/v1/tenants", w.handleTenantAPI)
	mux.HandleFunc("/api/v1/tenants/", w.handleTenantAPIWithID)
	
	w.logger.Info("API routes registered", logger.Fields{
		"routes": []string{"/api/v1/tenants", "/api/v1/tenants/*"},
	})
}

// serveDashboard serves the main dashboard page
func (wh *WebHandler) serveDashboard(wr http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	
	// Create dashboard component
	dashboard := wh.createDashboardPage()
	
	// Render component
	wr.Header().Set("Content-Type", "text/html")
	if err := dashboard.Render(ctx, wr); err != nil {
		wh.logger.Error("Failed to render dashboard", logger.Fields{"error": err.Error()})
		http.Error(wr, "Internal Server Error", http.StatusInternalServerError)
		return
	}
}

// serveComponentsDemo serves a components demonstration page
func (wh *WebHandler) serveComponentsDemo(wr http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	
	// Create components demo page
	demo := wh.createComponentsDemo()
	
	// Render component
	wr.Header().Set("Content-Type", "text/html")
	if err := demo.Render(ctx, wr); err != nil {
		wh.logger.Error("Failed to render components demo", logger.Fields{"error": err.Error()})
		http.Error(wr, "Internal Server Error", http.StatusInternalServerError)
		return
	}
}

// serveTenantListPage serves the tenant list page with layout
func (wh *WebHandler) serveTenantListPage(wr http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	
	// Get tenants using the service
	tenants, err := wh.serviceContainer.GetTenantService().ListTenants(ctx, 0, 20)
	if err != nil {
		wh.logger.Error("Failed to get tenants", logger.Fields{"error": err.Error()})
		http.Error(wr, "Internal Server Error", http.StatusInternalServerError)
		return
	}
	
	// Convert to API format
	apiTenants := make([]*genTenant.Tenant, len(tenants))
	for i, t := range tenants {
		apiTenants[i] = wh.convertTenantToAPI(t)
	}
	
	// Create pagination
	pagination := &tenantComponents.PaginationInfo{
		Page:       1,
		PerPage:    20,
		Total:      len(tenants),
		TotalPages: 1,
	}
	
	// Create tenant list component wrapped in layout
	tenantList := tenantComponents.TenantList(tenantComponents.TenantListProps{
		Tenants:    apiTenants,
		Pagination: pagination,
	})
	
	page := wh.createLayoutPage("Tenant Management", tenantList)
	
	// Render page
	wr.Header().Set("Content-Type", "text/html")
	if err := page.Render(ctx, wr); err != nil {
		wh.logger.Error("Failed to render tenant list", logger.Fields{"error": err.Error()})
		http.Error(wr, "Internal Server Error", http.StatusInternalServerError)
		return
	}
}

// serveTenantNewPage serves the new tenant form page
func (wh *WebHandler) serveTenantNewPage(wr http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	
	// Create new tenant form component
	form := tenantComponents.TenantForm(tenantComponents.TenantFormProps{
		Action:    "create",
		ActionURL: "/api/v1/tenants",
	})
	
	page := wh.createLayoutPage("Create New Tenant", form)
	
	// Render page
	wr.Header().Set("Content-Type", "text/html")
	if err := page.Render(ctx, wr); err != nil {
		wh.logger.Error("Failed to render new tenant form", logger.Fields{"error": err.Error()})
		http.Error(wr, "Internal Server Error", http.StatusInternalServerError)
		return
	}
}

// serveTenantEditPage serves the edit tenant form page
func (wh *WebHandler) serveTenantEditPage(wr http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	
	// Extract tenant ID from URL
	path := strings.TrimPrefix(r.URL.Path, "/tenants/edit/")
	if path == "" {
		http.NotFound(wr, r)
		return
	}
	
	// Get tenant by ID (simplified - in real implementation would parse UUID)
	// For now, create a placeholder
	form := tenantComponents.TenantForm(tenantComponents.TenantFormProps{
		Action:    "edit",
		ActionURL: "/api/v1/tenants/" + path,
	})
	
	page := wh.createLayoutPage("Edit Tenant", form)
	
	// Render page
	wr.Header().Set("Content-Type", "text/html")
	if err := page.Render(ctx, wr); err != nil {
		wh.logger.Error("Failed to render edit tenant form", logger.Fields{"error": err.Error()})
		http.Error(wr, "Internal Server Error", http.StatusInternalServerError)
		return
	}
}

// serveTenantViewPage serves the tenant detail view page
func (wh *WebHandler) serveTenantViewPage(wr http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	
	// Extract tenant ID from URL
	path := strings.TrimPrefix(r.URL.Path, "/tenants/view/")
	if path == "" {
		http.NotFound(wr, r)
		return
	}
	
	// Create placeholder tenant detail (in real implementation would fetch from service)
	sampleTenant := wh.createSampleTenant()
	detail := tenantComponents.TenantDetail(sampleTenant)
	
	page := wh.createLayoutPage("Tenant Details", detail)
	
	// Render page
	wr.Header().Set("Content-Type", "text/html")
	if err := page.Render(ctx, wr); err != nil {
		wh.logger.Error("Failed to render tenant detail", logger.Fields{"error": err.Error()})
		http.Error(wr, "Internal Server Error", http.StatusInternalServerError)
		return
	}
}

// createLayoutPage creates a common layout wrapper for pages
func (wh *WebHandler) createLayoutPage(title string, content templ.Component) templ.Component {
	return templ.ComponentFunc(func(ctx context.Context, wr io.Writer) error {
		_, err := wr.Write([]byte(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>` + title + ` - ERP System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/htmx.org@1.9.10"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <header class="bg-white shadow-sm border-b">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <h1 class="text-2xl font-bold text-gray-900">ERP System</h1>
                    </div>
                    <nav class="flex space-x-8">
                        <a href="/dashboard" class="text-gray-500 hover:text-gray-700">Dashboard</a>
                        <a href="/tenants" class="text-gray-900 hover:text-gray-700">Tenants</a>
                        <a href="/components" class="text-gray-500 hover:text-gray-700">Components</a>
                    </nav>
                </div>
            </div>
        </header>
        
        <main id="main-content" class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div class="px-4 py-6 sm:px-0">
`))
		if err != nil {
			return err
		}
		
		// Render the content component
		if err := content.Render(ctx, wr); err != nil {
			return err
		}
		
		_, err = wr.Write([]byte(`
            </div>
        </main>
    </div>
</body>
</html>
`))
		return err
	})
}

// createDashboardPage creates the main dashboard template
func (wh *WebHandler) createDashboardPage() templ.Component {
	return templ.ComponentFunc(func(ctx context.Context, wr io.Writer) error {
		_, err := wr.Write([]byte(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERP Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <header class="bg-white shadow-sm border-b">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <h1 class="text-2xl font-bold text-gray-900">ERP Dashboard</h1>
                    </div>
                    <nav class="flex space-x-8">
                        <a href="/dashboard" class="text-gray-900 hover:text-gray-700">Dashboard</a>
                        <a href="/tenants" class="text-gray-500 hover:text-gray-700">Tenants</a>
                        <a href="/components" class="text-gray-500 hover:text-gray-700">Components</a>
                    </nav>
                </div>
            </div>
        </header>
        
        <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div class="px-4 py-6 sm:px-0">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
`))
		if err != nil {
			return err
		}
		
		// Render dashboard cards
		cards := []struct {
			title string
			link  string
		}{
			{"Tenant Management", "/tenants"},
			{"Financial Overview", "/finance"},
			{"System Health", "/health"},
		}
		
		for _, card := range cards {
			_, err = wr.Write([]byte(`
					<a href="` + card.link + `" class="block">
						<div class="bg-white shadow rounded-lg hover:shadow-lg transition-shadow">
							<div class="p-6">
								<h3 class="text-lg font-medium text-gray-900 mb-4">` + card.title + `</h3>
								<p class="text-gray-600">Manage and overview ` + strings.ToLower(card.title) + `.</p>
							</div>
						</div>
					</a>
				`))
			if err != nil {
				return err
			}
		}
		
		_, err = wr.Write([]byte(`
                </div>
            </div>
        </main>
    </div>
</body>
</html>
`))
		return err
	})
}

// createComponentsDemo creates a components demonstration page
func (wh *WebHandler) createComponentsDemo() templ.Component {
	return templ.ComponentFunc(func(ctx context.Context, wr io.Writer) error {
		_, err := wr.Write([]byte(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UI Components Demo</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <header class="bg-white shadow-sm border-b">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <h1 class="text-2xl font-bold text-gray-900">UI Components</h1>
                    </div>
                    <nav class="flex space-x-8">
                        <a href="/dashboard" class="text-gray-500 hover:text-gray-700">Dashboard</a>
                        <a href="/tenants" class="text-gray-500 hover:text-gray-700">Tenants</a>
                        <a href="/components" class="text-gray-900 hover:text-gray-700">Components</a>
                    </nav>
                </div>
            </div>
        </header>
        
        <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div class="px-4 py-6 sm:px-0">
                <div class="space-y-8">
                    <section>
                        <h2 class="text-xl font-semibold text-gray-900 mb-4">Available Components</h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="bg-white shadow rounded-lg">
                                <div class="p-6">
                                    <h3 class="text-lg font-medium text-gray-900 mb-2">Tenant Components</h3>
                                    <p class="text-gray-600">Cards, lists, forms, and detail views for tenant management.</p>
                                    <a href="/tenants" class="mt-4 inline-flex items-center text-indigo-600 hover:text-indigo-500">
                                        View in action →
                                    </a>
                                </div>
                            </div>
                            <div class="bg-white shadow rounded-lg">
                                <div class="p-6">
                                    <h3 class="text-lg font-medium text-gray-900 mb-2">TemplUI Library</h3>
                                    <p class="text-gray-600">Complete UI component library with Tailwind CSS styling.</p>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
`))
		return err
	})
}

// Helper functions

// convertTenantToAPI converts a core tenant to API format
func (wh *WebHandler) convertTenantToAPI(t interface{}) *genTenant.Tenant {
	// This is a simplified conversion - in real implementation would properly convert
	return &genTenant.Tenant{
		ID:           "sample-id",
		Name:         "Sample Tenant",
		Slug:         "sample-tenant",
		Email:        "admin@sample.com",
		Status:       "ACTIVE",
		Timezone:     "UTC",
		CurrencyCode: "USD",
		CreatedAt:    "2023-01-01T00:00:00Z",
	}
}

// createSampleTenant creates a sample tenant for demo purposes
func (wh *WebHandler) createSampleTenant() *genTenant.Tenant {
	return &genTenant.Tenant{
		ID:           "123e4567-e89b-12d3-a456-426614174000",
		Name:         "Acme Corporation",
		Slug:         "acme-corp",
		Email:        "admin@acme.com",
		Status:       "ACTIVE",
		Timezone:     "UTC",
		CurrencyCode: "USD",
		CreatedAt:    "2023-01-01T00:00:00Z",
	}
}

// handleTenantAPI handles tenant list and create operations
func (wh *WebHandler) handleTenantAPI(wr http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case "GET":
		wh.handleTenantList(wr, r)
	case "POST":
		wh.handleTenantCreate(wr, r)
	default:
		http.Error(wr, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// handleTenantAPIWithID handles tenant operations with ID (get, update, delete)
func (wh *WebHandler) handleTenantAPIWithID(wr http.ResponseWriter, r *http.Request) {
	// Extract tenant ID from URL
	path := strings.TrimPrefix(r.URL.Path, "/api/v1/tenants/")
	if path == "" {
		http.Error(wr, "Tenant ID required", http.StatusBadRequest)
		return
	}
	
	// Handle specific sub-routes
	if strings.HasSuffix(path, "/edit") {
		// GET /api/v1/tenants/{id}/edit - Edit form
		tenantID := strings.TrimSuffix(path, "/edit")
		wh.handleTenantEditForm(wr, r, tenantID)
		return
	}
	
	// Regular CRUD operations
	switch r.Method {
	case "GET":
		wh.handleTenantGet(wr, r, path)
	case "PUT", "PATCH":
		wh.handleTenantUpdate(wr, r, path)
	case "DELETE":
		wh.handleTenantDelete(wr, r, path)
	default:
		http.Error(wr, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// handleTenantList handles GET /api/v1/tenants
func (wh *WebHandler) handleTenantList(wr http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	
	// Get tenants from service
	tenants, err := wh.serviceContainer.GetTenantService().ListTenants(ctx, 0, 20)
	if err != nil {
		wh.logger.ErrorContext(ctx, "Failed to list tenants", logger.Fields{"error": err.Error()})
		http.Error(wr, "Failed to list tenants", http.StatusInternalServerError)
		return
	}
	
	// Convert to API format
	apiTenants := make([]*genTenant.Tenant, len(tenants))
	for i, t := range tenants {
		apiTenants[i] = wh.convertTenantToAPI(t)
	}
	
	// Check content negotiation
	if wh.wantsHTML(r) {
		// Return HTML component
		pagination := &tenantComponents.PaginationInfo{
			Page:       1,
			PerPage:    20,
			Total:      len(tenants),
			TotalPages: 1,
		}
		
		component := tenantComponents.TenantList(tenantComponents.TenantListProps{
			Tenants:    apiTenants,
			Pagination: pagination,
		})
		
		wr.Header().Set("Content-Type", "text/html")
		if err := component.Render(ctx, wr); err != nil {
			wh.logger.ErrorContext(ctx, "Failed to render tenant list", logger.Fields{"error": err.Error()})
			http.Error(wr, "Failed to render response", http.StatusInternalServerError)
		}
		return
	}
	
	// Return JSON
	wr.Header().Set("Content-Type", "application/json")
	wr.WriteHeader(http.StatusOK)
	// In a real implementation, would use json.NewEncoder(wr).Encode(response)
	wr.Write([]byte(`{"status":"success","message":"Tenant list API - JSON response would be here"}`))
}

// handleTenantCreate handles POST /api/v1/tenants  
func (wh *WebHandler) handleTenantCreate(wr http.ResponseWriter, r *http.Request) {
	ctx := r.Context()
	
	// For demo purposes, create a sample tenant
	sampleTenant := wh.createSampleTenant()
	
	// Check content negotiation
	if wh.wantsHTML(r) {
		// Return HTML component
		component := tenantComponents.TenantCard(tenantComponents.TenantCardProps{
			Tenant:   sampleTenant,
			ShowEdit: true,
		})
		
		wr.Header().Set("Content-Type", "text/html")
		wr.WriteHeader(http.StatusCreated)
		if err := component.Render(ctx, wr); err != nil {
			wh.logger.ErrorContext(ctx, "Failed to render tenant card", logger.Fields{"error": err.Error()})
			http.Error(wr, "Failed to render response", http.StatusInternalServerError)
		}
		return
	}
	
	// Return JSON
	wr.Header().Set("Content-Type", "application/json")
	wr.WriteHeader(http.StatusCreated)
	wr.Write([]byte(`{"status":"created","message":"Tenant created - JSON response would be here"}`))
}

// handleTenantGet handles GET /api/v1/tenants/{id}
func (wh *WebHandler) handleTenantGet(wr http.ResponseWriter, r *http.Request, tenantID string) {
	ctx := r.Context()
	
	// For demo purposes, return sample tenant
	sampleTenant := wh.createSampleTenant()
	sampleTenant.ID = tenantID
	
	// Check content negotiation
	if wh.wantsHTML(r) {
		// Return HTML component
		component := tenantComponents.TenantDetail(sampleTenant)
		
		wr.Header().Set("Content-Type", "text/html")
		if err := component.Render(ctx, wr); err != nil {
			wh.logger.ErrorContext(ctx, "Failed to render tenant detail", logger.Fields{"error": err.Error()})
			http.Error(wr, "Failed to render response", http.StatusInternalServerError)
		}
		return
	}
	
	// Return JSON
	wr.Header().Set("Content-Type", "application/json")
	wr.WriteHeader(http.StatusOK)
	wr.Write([]byte(`{"status":"success","message":"Tenant detail - JSON response would be here"}`))
}

// handleTenantUpdate handles PUT/PATCH /api/v1/tenants/{id}
func (wh *WebHandler) handleTenantUpdate(wr http.ResponseWriter, r *http.Request, tenantID string) {
	ctx := r.Context()
	
	// For demo purposes, return updated tenant
	sampleTenant := wh.createSampleTenant()
	sampleTenant.ID = tenantID
	sampleTenant.Name = "Updated " + sampleTenant.Name
	
	// Check content negotiation
	if wh.wantsHTML(r) {
		// Return HTML component
		component := tenantComponents.TenantCard(tenantComponents.TenantCardProps{
			Tenant:   sampleTenant,
			ShowEdit: true,
		})
		
		wr.Header().Set("Content-Type", "text/html")
		if err := component.Render(ctx, wr); err != nil {
			wh.logger.ErrorContext(ctx, "Failed to render updated tenant", logger.Fields{"error": err.Error()})
			http.Error(wr, "Failed to render response", http.StatusInternalServerError)
		}
		return
	}
	
	// Return JSON
	wr.Header().Set("Content-Type", "application/json")
	wr.WriteHeader(http.StatusOK)
	wr.Write([]byte(`{"status":"updated","message":"Tenant updated - JSON response would be here"}`))
}

// handleTenantDelete handles DELETE /api/v1/tenants/{id}
func (wh *WebHandler) handleTenantDelete(wr http.ResponseWriter, r *http.Request, tenantID string) {
	// Return success response
	wr.Header().Set("Content-Type", "application/json")
	wr.WriteHeader(http.StatusNoContent)
}

// handleTenantEditForm handles GET /api/v1/tenants/{id}/edit
func (wh *WebHandler) handleTenantEditForm(wr http.ResponseWriter, r *http.Request, tenantID string) {
	ctx := r.Context()
	
	// Get tenant for editing (demo with sample data)
	sampleTenant := wh.createSampleTenant()
	sampleTenant.ID = tenantID
	
	// Always return HTML form for edit
	component := tenantComponents.TenantForm(tenantComponents.TenantFormProps{
		Tenant:    sampleTenant,
		Action:    "edit",
		ActionURL: "/api/v1/tenants/" + tenantID,
	})
	
	wr.Header().Set("Content-Type", "text/html")
	if err := component.Render(ctx, wr); err != nil {
		wh.logger.ErrorContext(ctx, "Failed to render edit form", logger.Fields{"error": err.Error()})
		http.Error(wr, "Failed to render response", http.StatusInternalServerError)
	}
}

// wantsHTML determines if the client wants HTML response based on headers
func (wh *WebHandler) wantsHTML(r *http.Request) bool {
	acceptHeader := r.Header.Get("Accept")
	contentType := r.Header.Get("Content-Type")
	isHTMX := r.Header.Get("HX-Request") == "true"
	
	// Return HTML if:
	// 1. HTMX request
	// 2. Accept header contains text/html
	// 3. No specific Accept header (browser default)
	return isHTMX || 
		   strings.Contains(acceptHeader, "text/html") ||
		   (acceptHeader == "" || acceptHeader == "*/*") && 
		   !strings.Contains(contentType, "application/json")
}

