// Package identity has been merged into awo/internal/core/iam.
// This directory can be deleted.
package identity
