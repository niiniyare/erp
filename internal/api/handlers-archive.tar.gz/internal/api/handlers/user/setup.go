package user

import (
	"github.com/gofiber/fiber/v2"
	"github.com/niiniyare/erp/cmd/server/services"
	db "github.com/niiniyare/erp/db/sqlc"
	"github.com/niiniyare/erp/internal/core/iam"
	"github.com/niiniyare/erp/internal/platform/cache"
)

// SetupRoutes configures user management routes
func SetupRoutes(router fiber.Router, store db.Store, cacheService cache.Service, coreServices *services.CoreServices, iamService iam.Service) {
	// Initialize handlers with dependencies
	handler := &UserHandler{
		Store:        store,
		CacheService: cacheService,
		CoreServices: coreServices,
		IAMService:   iamService,
	}

	// User CRUD operations
	router.Get("/", handler.ListUsers)
	router.Get("/:id", handler.GetUser)
	router.Put("/:id", handler.UpdateUser)
	router.Delete("/:id", handler.DeleteUser)

	// User profile management
	router.Get("/:id/profile", handler.GetUserProfile)
	router.Put("/:id/profile", handler.UpdateUserProfile)

	// User permissions and roles
	router.Get("/:id/permissions", handler.GetUserPermissions)
	router.Put("/:id/permissions", handler.UpdateUserPermissions)
	router.Get("/:id/roles", handler.GetUserRoles)
	router.Put("/:id/roles", handler.UpdateUserRoles)

	// User status management
	router.Put("/:id/status", handler.UpdateUserStatus)
	router.Put("/:id/activate", handler.ActivateUser)
	router.Put("/:id/deactivate", handler.DeactivateUser)
}

// UserHandler holds dependencies for user operations
type UserHandler struct {
	Store        db.Store
	CacheService cache.Service
	CoreServices *services.CoreServices
	IAMService   iam.Service
}