package access

import (
	"github.com/gofiber/fiber/v2"
	"github.com/niiniyare/erp/cmd/server/services"
	db "github.com/niiniyare/erp/db/sqlc"
	"github.com/niiniyare/erp/internal/core/iam"
	"github.com/niiniyare/erp/internal/platform/cache"
)

// SetupRoutes configures access management routes
func SetupRoutes(router fiber.Router, store db.Store, cacheService cache.Service, coreServices *services.CoreServices, iamService iam.Service) {
	// Initialize handlers with dependencies
	handler := &AccessHandler{
		Store:        store,
		CacheService: cacheService,
		CoreServices: coreServices,
		IAMService:   iamService,
	}

	// Access request operations
	router.Post("/requests", handler.CreateAccessRequest)
	router.Get("/requests", handler.ListAccessRequests)
	router.Get("/requests/:id", handler.GetAccessRequest)
	router.Put("/requests/:id", handler.UpdateAccessRequest)

	// Access request status
	router.Put("/requests/:id/approve", handler.ApproveAccessRequest)
	router.Put("/requests/:id/deny", handler.DenyAccessRequest)
	router.Put("/requests/:id/cancel", handler.CancelAccessRequest)

	// User access permissions
	router.Get("/permissions", handler.GetMyPermissions)
	router.Get("/roles", handler.GetMyRoles)
}

// SetupAdminRoutes configures admin access management routes
func SetupAdminRoutes(router fiber.Router, store db.Store, cacheService cache.Service, coreServices *services.CoreServices, iamService iam.Service) {
	// Initialize handlers with dependencies
	handler := &AccessHandler{
		Store:        store,
		CacheService: cacheService,
		CoreServices: coreServices,
		IAMService:   iamService,
	}

	// Admin access request management
	router.Delete("/requests/:id", handler.DeleteAccessRequest)
	router.Get("/requests/pending", handler.ListPendingAccessRequests)
	router.Get("/requests/analytics", handler.GetAccessRequestAnalytics)

	// Role and permission management
	router.Post("/roles", handler.CreateRole)
	router.Get("/roles", handler.ListRoles)
	router.Put("/roles/:id", handler.UpdateRole)
	router.Delete("/roles/:id", handler.DeleteRole)

	router.Post("/permissions", handler.CreatePermission)
	router.Get("/permissions", handler.ListPermissions)
	router.Put("/permissions/:id", handler.UpdatePermission)
	router.Delete("/permissions/:id", handler.DeletePermission)

	// Access policy management
	router.Post("/policies", handler.CreateAccessPolicy)
	router.Get("/policies", handler.ListAccessPolicies)
	router.Put("/policies/:id", handler.UpdateAccessPolicy)
	router.Delete("/policies/:id", handler.DeleteAccessPolicy)
}

// AccessHandler holds dependencies for access management operations
type AccessHandler struct {
	Store        db.Store
	CacheService cache.Service
	CoreServices *services.CoreServices
	IAMService   iam.Service
}