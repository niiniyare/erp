package tenant

import (
	"github.com/gofiber/fiber/v2"
	"github.com/niiniyare/erp/cmd/server/services"
	db "github.com/niiniyare/erp/db/sqlc"
	"github.com/niiniyare/erp/internal/platform/cache"
)

// SetupRoutes configures tenant management routes
func SetupRoutes(router fiber.Router, store db.Store, cacheService cache.Service, coreServices *services.CoreServices) {
	// Initialize handlers with dependencies
	handler := &TenantHandler{
		Store:        store,
		CacheService: cacheService,
		CoreServices: coreServices,
	}

	// Tenant CRUD operations
	router.Post("/", handler.CreateTenant)
	router.Get("/", handler.ListTenants)
	router.Get("/:id", handler.GetTenant)
	router.Put("/:id", handler.UpdateTenant)
	router.Delete("/:id", handler.DeleteTenant)

	// Tenant status management
	router.Put("/:id/status", handler.UpdateTenantStatus)
	router.Put("/:id/suspend", handler.SuspendTenant)
	router.Put("/:id/activate", handler.ActivateTenant)

	// Tenant provisioning
	router.Post("/:id/provision", handler.ProvisionTenant)
	router.Get("/:id/provision/status", handler.GetProvisioningStatus)
}

// TenantHandler holds dependencies for tenant operations
type TenantHandler struct {
	Store        db.Store
	CacheService cache.Service
	CoreServices *services.CoreServices
}