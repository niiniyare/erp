package featureflag

import (
	"github.com/gofiber/fiber/v2"
	"github.com/niiniyare/erp/cmd/server/services"
	db "github.com/niiniyare/erp/db/sqlc"
	"github.com/niiniyare/erp/internal/platform/cache"
)

// SetupRoutes configures feature flag management routes
func SetupRoutes(router fiber.Router, store db.Store, cacheService cache.Service, coreServices *services.CoreServices) {
	// Initialize handlers with dependencies
	handler := &FeatureFlagHandler{
		Store:        store,
		CacheService: cacheService,
		CoreServices: coreServices,
	}

	// Feature flag CRUD operations
	router.Get("/", handler.ListFeatureFlags)
	router.Get("/:id", handler.GetFeatureFlag)
	router.Put("/:id", handler.UpdateFeatureFlag)

	// Feature flag evaluation
	router.Post("/evaluate", handler.EvaluateFeatureFlag)
	router.Post("/evaluate/:key", handler.EvaluateFeatureFlagByKey)

	// Feature flag status
	router.Put("/:id/enable", handler.EnableFeatureFlag)
	router.Put("/:id/disable", handler.DisableFeatureFlag)
	router.Get("/:id/status", handler.GetFeatureFlagStatus)
}

// SetupAdminRoutes configures admin feature flag management routes
func SetupAdminRoutes(router fiber.Router, store db.Store, cacheService cache.Service, coreServices *services.CoreServices) {
	// Initialize handlers with dependencies
	handler := &FeatureFlagHandler{
		Store:        store,
		CacheService: cacheService,
		CoreServices: coreServices,
	}

	// Admin feature flag operations
	router.Post("/", handler.CreateFeatureFlag)
	router.Delete("/:id", handler.DeleteFeatureFlag)
	
	// Feature flag configuration
	router.Put("/:id/config", handler.UpdateFeatureFlagConfig)
	router.Get("/:id/config", handler.GetFeatureFlagConfig)
	
	// Feature flag rollout management
	router.Put("/:id/rollout", handler.UpdateFeatureFlagRollout)
	router.Get("/:id/rollout", handler.GetFeatureFlagRollout)
	
	// Feature flag analytics
	router.Get("/:id/analytics", handler.GetFeatureFlagAnalytics)
	router.Get("/analytics/summary", handler.GetFeatureFlagsSummary)
}

// FeatureFlagHandler holds dependencies for feature flag operations
type FeatureFlagHandler struct {
	Store        db.Store
	CacheService cache.Service
	CoreServices *services.CoreServices
}