package handlers

import (
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/helmet"
	"github.com/gofiber/fiber/v2/middleware/limiter"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/gofiber/fiber/v2/middleware/requestid"
	"github.com/niiniyare/erp/cmd/server/services"
	db "github.com/niiniyare/erp/db/sqlc"
	financeService "github.com/niiniyare/erp/internal/core/finance/service"
	"github.com/niiniyare/erp/internal/core/iam"
	"github.com/niiniyare/erp/internal/platform/cache"
	"github.com/niiniyare/erp/internal/platform/config"
	"github.com/niiniyare/erp/internal/platform/middleware"
	sharedLogger "github.com/niiniyare/erp/internal/shared/logger"
	"github.com/niiniyare/erp/internal/shared/metrics"
	"github.com/niiniyare/erp/internal/shared/tracing"
)

// Server represents the HTTP server with all dependencies
type Server struct {
	App             *fiber.App
	Config          *config.Config
	CoreServices    *services.CoreServices
	FinanceServices *financeService.Services
	Store           db.Store
	CacheService    cache.Service
	MetricsService  *metrics.MetricsService
	TracingService  tracing.TracingService
	IAMService      iam.Service
}

// ServerConfig holds configuration for server initialization
type ServerConfig struct {
	Config          *config.Config
	CoreServices    *services.CoreServices
	FinanceServices *financeService.Services
	Store           db.Store
	CacheService    cache.Service
	MetricsService  *metrics.MetricsService
	TracingService  tracing.TracingService
	IAMService      iam.Service
}

// NewServer creates a new HTTP server with all dependencies
func NewServer(cfg ServerConfig) (*Server, error) {
	// Create Fiber app with configuration
	app := fiber.New(fiber.Config{
		ErrorHandler:  createFiberErrorHandler(),
		ReadTimeout:   cfg.Config.Server.ReadTimeout,
		WriteTimeout:  cfg.Config.Server.WriteTimeout,
		IdleTimeout:   120 * time.Second,
		Prefork:       false,
		ServerHeader:  "ERP-API",
		AppName:       cfg.Config.App.Name + " v" + cfg.Config.App.Version,
		CaseSensitive: false,
		StrictRouting: false,
	})

	server := &Server{
		App:             app,
		Config:          cfg.Config,
		CoreServices:    cfg.CoreServices,
		FinanceServices: cfg.FinanceServices,
		Store:           cfg.Store,
		CacheService:    cfg.CacheService,
		MetricsService:  cfg.MetricsService,
		TracingService:  cfg.TracingService,
		IAMService:      cfg.IAMService,
	}

	// Setup middleware
	server.setupMiddleware()

	// Setup routes
	server.setupRoutes()

	return server, nil
}

// setupMiddleware configures all middleware for the server
func (s *Server) setupMiddleware() {
	// Recovery middleware
	s.App.Use(recover.New())

	// Request ID middleware
	s.App.Use(requestid.New())

	// Logger middleware
	s.App.Use(logger.New(logger.Config{
		Format: "${cyan}${time} ${white}${pid} ${red}${status} ${blue}[${method}] ${white}${path}${reset} ${yellow}${body}${reset}\n",
	}))

	// Security middleware
	s.App.Use(helmet.New())

	// Rate limiting middleware
	s.App.Use(limiter.New(limiter.Config{
		Max:               100,
		Expiration:        1 * time.Minute,
		LimiterMiddleware: limiter.SlidingWindow{},
	}))

	// Custom middleware
	s.App.Use(middleware.CORS())
	s.App.Use(middleware.RequestLogging(sharedLogger.WithFields(sharedLogger.Fields{
		"component": "http-server",
	})))

	// Feature flag middleware for endpoints that need it
	featureFlagMiddleware := middleware.FeatureFlag(s.CoreServices.FeatureFlagService)
	s.App.Use("/api/v1/admin/*", featureFlagMiddleware)
}

// Start starts the HTTP server
func (s *Server) Start() error {
	addr := ":" + s.Config.Server.Port
	sharedLogger.Info("Starting Fiber HTTP server", sharedLogger.Fields{
		"address": addr,
		"app":     s.Config.App.Name,
		"port":    s.Config.Server.Port,
		"version": s.Config.App.Version,
	})

	return s.App.Listen(addr)
}

// Shutdown gracefully shuts down the server
func (s *Server) Shutdown() error {
	return s.App.Shutdown()
}

// createFiberErrorHandler creates a custom error handler for Fiber
func createFiberErrorHandler() fiber.ErrorHandler {
	return func(c *fiber.Ctx, err error) error {
		code := fiber.StatusInternalServerError
		if e, ok := err.(*fiber.Error); ok {
			code = e.Code
		}

		return c.Status(code).JSON(fiber.Map{
			"error":   true,
			"message": err.Error(),
		})
	}
}