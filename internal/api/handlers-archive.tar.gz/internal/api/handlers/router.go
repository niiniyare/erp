package handlers

import (
	"github.com/gofiber/fiber/v2"
	sharedLogger "github.com/niiniyare/erp/internal/shared/logger"
)

// setupRoutes configures all routes for the server
func (s *Server) setupRoutes() {
	// API version 1
	api := s.App.Group("/api/v1")

	// Health check route
	api.Get("/health", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"status": "ok"})
	})

	// Placeholder routes - will be implemented with proper handlers
	api.Get("/tenants", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"message": "tenant routes will be implemented"})
	})

	api.Get("/users", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"message": "user routes will be implemented"})
	})

	api.Get("/auth/login", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"message": "auth routes will be implemented"})
	})

	// Setup OpenAPI/Swagger routes
	s.setupOpenAPIRoutes()

	sharedLogger.Info("Fiber server routes initialized", sharedLogger.Fields{
		"api_version": "v1",
		"endpoints":   "health, tenants, users, auth (placeholders)",
		"port":        s.Config.Server.Port,
	})
}


// setupOpenAPIRoutes configures OpenAPI/Swagger routes
func (s *Server) setupOpenAPIRoutes() {
	// OpenAPI JSON endpoint
	s.App.Get("/openapi.json", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{
			"openapi": "3.0.0",
			"info": fiber.Map{
				"title":   s.Config.App.Name,
				"version": s.Config.App.Version,
			},
		})
	})

	// Swagger UI endpoint
	s.App.Get("/swagger/*", func(c *fiber.Ctx) error {
		return c.SendString("Swagger UI will be served here")
	})
}