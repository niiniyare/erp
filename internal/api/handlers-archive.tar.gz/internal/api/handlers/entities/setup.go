package entities

import (
	"github.com/gofiber/fiber/v2"
	"github.com/niiniyare/erp/cmd/server/services"
	db "github.com/niiniyare/erp/db/sqlc"
	"github.com/niiniyare/erp/internal/platform/cache"
)

// SetupRoutes configures entity management routes
func SetupRoutes(router fiber.Router, store db.Store, cacheService cache.Service, coreServices *services.CoreServices) {
	// Initialize handlers with dependencies
	handler := &EntityHandler{
		Store:        store,
		CacheService: cacheService,
		CoreServices: coreServices,
	}

	// Entity CRUD operations
	router.Post("/", handler.CreateEntity)
	router.Get("/", handler.ListEntities)
	router.Get("/:id", handler.GetEntity)
	router.Put("/:id", handler.UpdateEntity)
	router.Delete("/:id", handler.DeleteEntity)

	// Entity relationships
	router.Get("/:id/relationships", handler.GetEntityRelationships)
	router.Post("/:id/relationships", handler.CreateEntityRelationship)
	router.Delete("/:id/relationships/:rel_id", handler.DeleteEntityRelationship)

	// Entity attributes
	router.Get("/:id/attributes", handler.GetEntityAttributes)
	router.Put("/:id/attributes", handler.UpdateEntityAttributes)

	// Entity validation
	router.Post("/:id/validate", handler.ValidateEntity)
	router.Get("/:id/schema", handler.GetEntitySchema)
}

// EntityHandler holds dependencies for entity operations
type EntityHandler struct {
	Store        db.Store
	CacheService cache.Service
	CoreServices *services.CoreServices
}