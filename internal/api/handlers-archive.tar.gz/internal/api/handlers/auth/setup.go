package auth

import (
	"github.com/gofiber/fiber/v2"
	"github.com/niiniyare/erp/internal/core/iam"
	db "github.com/niiniyare/erp/db/sqlc"
	"github.com/niiniyare/erp/internal/platform/cache"
)

// SetupRoutes configures authentication routes
func SetupRoutes(router fiber.Router, store db.Store, cacheService cache.Service, iamService iam.Service) {
	// Initialize handlers with dependencies
	handler := &AuthHandler{
		Store:        store,
		CacheService: cacheService,
		IAMService:   iamService,
	}

	// Authentication routes
	router.Post("/login", handler.Login)
	router.Post("/logout", handler.Logout)
	router.Post("/refresh", handler.RefreshToken)
	router.Post("/forgot-password", handler.ForgotPassword)
	router.Post("/reset-password", handler.ResetPassword)
	router.Post("/verify-email", handler.VerifyEmail)
	router.Post("/resend-verification", handler.ResendVerification)

	// Profile management
	router.Get("/profile", handler.GetProfile)
	router.Put("/profile", handler.UpdateProfile)
	router.Post("/change-password", handler.ChangePassword)
}

// AuthHandler holds dependencies for authentication operations
type AuthHandler struct {
	Store        db.Store
	CacheService cache.Service
	IAMService   iam.Service
}